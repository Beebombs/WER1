import { useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";

// Nature prompts
const NATURE_PROMPTS = [
  "Go lie naked in the grass",
  "Go for a walk in the woods without your shoes",
  "Stare at your naked self in the mirror. Own what you see, love what you see. It’s just you and you are vital",
  "Hug a tree bare-chested. Nobody is around. It feels so good.",
];

const Index = () => {
  // Section refs for smooth scroll
  const heroRef = useRef<HTMLElement>(null);
  const planRef = useRef<HTMLElement>(null);
  const releaseRef = useRef<HTMLElement>(null);
  const natureRef = useRef<HTMLElement>(null);

  // Form state
  const [plan, setPlan] = useState("");
  const [worries, setWorries] = useState("");

  // Animation state
  const [playBurst, setPlayBurst] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReducedMotion(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, []);

  // Random nature prompt (re-roll on every release)
  const [promptIndex, setPromptIndex] = useState(() => Math.floor(Math.random() * NATURE_PROMPTS.length));
  const naturePrompt = useMemo(() => NATURE_PROMPTS[promptIndex], [promptIndex]);

  const scrollTo = (ref: React.RefObject<HTMLElement>) => {
    ref.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const onCopyPlan = async () => {
    try {
      await navigator.clipboard.writeText(plan);
      toast({ title: "Plan copied", description: "Your plan is ready to paste." });
      const live = document.getElementById("live-region");
      if (live) live.textContent = "Plan copied to clipboard";
    } catch {
      toast({ title: "Copy failed", description: "Please try again." });
    }
  };

  const onLetItGo = () => {
    if (reducedMotion) {
      setWorries("");
      setPromptIndex(Math.floor(Math.random() * NATURE_PROMPTS.length));
      scrollTo(natureRef);
      return;
    }
    setPlayBurst(true);
    setTimeout(() => {
      setPlayBurst(false);
      setWorries("");
      setPromptIndex(Math.floor(Math.random() * NATURE_PROMPTS.length));
      scrollTo(natureRef);
    }, 1150);
  };

  return (
    <main aria-label="AllU – Gentle Daily Ritual">
      {/* Live region for a11y feedback */}
      <div id="live-region" aria-live="polite" className="sr-only" />

      {/* 1) Hero */}
      <section ref={heroRef} id="hero" className="min-h-screen grid place-items-center px-6">
        <Card className="surface-glass w-full max-w-3xl animate-enter">
          <CardContent className="p-8 md:p-12">
            <div className="text-center space-y-5">
              <h1 className="wordmark text-5xl md:text-6xl font-semibold tracking-tight">AllU</h1>
              <p className="text-xl md:text-2xl text-muted-foreground">Simply Happy.</p>
              <p className="text-base md:text-lg text-foreground/80">
                A gentle daily rhythm: set your plan, release what weighs you down, then step outside for a breath of nature.
              </p>
              <div className="pt-2">
                <Button size="lg" onClick={() => scrollTo(planRef)} className="hover-scale">
                  Get Started
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* 2) Plan */}
      <section ref={planRef} id="plan" className="min-h-screen grid place-items-center px-6">
        <Card className="surface-glass w-full max-w-3xl animate-enter">
          <CardContent className="p-8 md:p-12 space-y-6">
            <header>
              <h2 className="text-2xl md:text-3xl font-semibold">Plan</h2>
              <p className="text-muted-foreground mt-2">
                What do you need to do today, irrespective of how you feel?
              </p>
            </header>
            <div>
              <label htmlFor="plan-text" className="sr-only">Plan input</label>
              <Textarea
                id="plan-text"
                className="min-h-[220px]"
                placeholder="Write your plan as a simple list..."
                value={plan}
                onChange={(e) => setPlan(e.target.value)}
              />
            </div>
            <div className="flex flex-col sm:flex-row gap-3 justify-between">
              <Button variant="secondary" onClick={onCopyPlan} className="hover-scale">Copy plan</Button>
              <Button onClick={() => scrollTo(releaseRef)} className="hover-scale">Next</Button>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* 3) Release */}
      <section ref={releaseRef} id="release" className="min-h-screen grid place-items-center px-6">
        <Card className="surface-glass w-full max-w-3xl animate-enter">
          <CardContent className="p-8 md:p-12 space-y-6">
            <header>
              <h2 className="text-2xl md:text-3xl font-semibold">Release</h2>
              <p className="text-muted-foreground mt-2">
                Write out the worries you can’t control. Let them disappear and set yourself free for the day.
              </p>
            </header>
            <div>
              <label htmlFor="worry-text" className="sr-only">Worries input</label>
              <Textarea
                id="worry-text"
                className="min-h-[180px]"
                placeholder="Let it out here..."
                value={worries}
                onChange={(e) => setWorries(e.target.value)}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="relative">
                <Button onClick={onLetItGo} className="hover-scale">Let it go</Button>
              </div>
              {/* Animation mount point */}
              {!reducedMotion && playBurst && (
                <div className="burst-wrap" aria-hidden>
                  <div className="burst-core" />
                  <div className="burst-ring" />
                  {/* Particles */}
                  {[...Array(6)].map((_, i) => (
                    <span
                      key={i}
                      className="burst-particle"
                      style={{
                        left: `${50 + Math.cos((i / 6) * 2 * Math.PI) * 60}px`,
                        top: `${-5 + Math.sin((i / 6) * 2 * Math.PI) * 30}px`,
                        animationDelay: `${i * 40}ms`,
                      }}
                    />
                  ))}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </section>

      {/* 4) Nature Nudge */}
      <section ref={natureRef} id="nature" className="min-h-screen grid place-items-center px-6">
        <Card className="surface-glass w-full max-w-3xl animate-enter">
          <CardContent className="p-8 md:p-12 space-y-6">
            <header className="space-y-2">
              <h2 className="text-2xl md:text-3xl font-semibold">Reconnect with nature</h2>
              <p className="text-muted-foreground">One small step to ground yourself.</p>
            </header>
            <article className="text-xl md:text-2xl font-semibold flex items-start gap-3">
              <span aria-hidden>🌿</span>
              <span>{naturePrompt}</span>
            </article>
            <div className="flex flex-col sm:flex-row gap-3 justify-between">
              <Button variant="secondary" onClick={() => scrollTo(heroRef)} className="hover-scale">Back to start</Button>
              <Button onClick={() => scrollTo(planRef)} className="hover-scale">New plan</Button>
            </div>
          </CardContent>
        </Card>
      </section>
    </main>
  );
};

export default Index;
